import 'dart:collection';
import 'dart:ffi';

import 'package:flutter/material.dart';

const BaseColor = Color(0xff34C76A);
const BackgroundColor = Color(0xffF2F2F2);
const SecColor = Color(0xfffec578);
const ThirdColor = Color(0xffdaa75b);
const GrayColor = Color(0xFFB1B1B1);
const GrayColor2 = Color(0xFFEEEEEE);
const BlueColor = Color(0xFF17374E);
const RedColor = Color(0xFF521920);
const Api = "https://bazinocargo.ir/api10";
const ApiKey = "l1sDfPlq9aLWq0Mz2";
const Url = "https://bazinocargo.ir";
const AppName = "Bazino";
const AppVersion = "100";
HashMap basketGlob = new HashMap<int, String>();
int BaseCatRef=0;
int CatRef=0;
int OrderRef=0;
int HasMsg=0;
String MsgApp="";
String TitleApp="";



