class OrdersModel {

  OrdersModel(this._ID, this._Active, this._Price, this._TotalPrice, this._PayType, this._Date);
  int _ID=0;
  int _Active=0;
  String _Price="";
  String _TotalPrice="";
  String _PayType="";
  String _Date="";

  int get Active => _Active;
  int get ID => _ID;
  String get Price => _Price;
  String get TotalPrice => _TotalPrice;
  String get PayType => _PayType;
  String get Date => _Date;
}