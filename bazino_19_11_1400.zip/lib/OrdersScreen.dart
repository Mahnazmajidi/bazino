import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bazino/utils/constants.dart';
import 'package:bazino/View/BottomNav.dart';
import 'package:lottie/lottie.dart';
import 'Controller/OrdersController.dart';
import 'Model/OrdersModel.dart';
import 'View/ApppBar.dart';
import 'View/Loading.dart';
import 'View/MsgBox.dart';
import 'View/MyDrawer.dart';

class OrdersScreen extends StatelessWidget {
  OrdersController ordersController = Get.put(OrdersController());

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Get.offAndToNamed("/CategoryScreen");
        return true;
      },
      child: Scaffold(
        endDrawer:MyDrawer(),
        // backgroundColor: Colors.white,
        body: Obx(() {
          return Container(
            decoration: new BoxDecoration(
              color: BaseColor,
              // borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
            ),
            child: Column(
              children: [
                ApppBar(title: "لیست سفارشات", back: "finish"),
                Expanded(
                  flex: 1,
                  child: ordersController.geted.value == 1
                      ? Loading():
                       ordersController.geted.value == 4?MsgBox(type:1,screen: "/OrdersScreen",)
                      : ordersController.geted.value == 3
                          ? Container(child: Text(ordersController.msg.value))
                          : Stack(
                              // overflow: Overflow.clip,
                              fit: StackFit.expand,
                              children: [
                                  Container(
                                    height: 200,
                                    margin: EdgeInsets.fromLTRB(10, 30, 10, 10),
                                    child: Card(
                                      semanticContainer: true,
                                      clipBehavior: Clip.antiAliasWithSaveLayer,
                                      // margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                      color: GrayColor2,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(40.0))),
                                      elevation: 6,
                                      child: Container(
                                        height: 100,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(15, 0, 15, 25),
                                    // transform: Matrix4.translationValues(0.0, -50.0, 0.0),
                                    child: ListView.builder(
                                      itemCount: ordersController.order.length,
                                      itemBuilder: (context, position) {
                                        return genItem(
                                            ordersController.order[position],
                                            position);
                                      },
                                      padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
                                    ),
                                  )
                                ]),
                )
              ],
            ),
          );
        }),
        bottomNavigationBar: BottomNav(),
        floatingActionButton: FloatingActionButton(
          onPressed: (){
            Get.offAndToNamed("/CategoryScreen");
          },
          child: Icon(
            Icons.home,
            color: SecColor,
          ),
          backgroundColor: BaseColor,
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }

  InkWell genItem(OrdersModel order, int position) {
    return InkWell(
      // splashColor: Colors.white,
      onTap: () {
        OrderRef=order.ID;
        Get.toNamed("/OrderDetailScreen");
        // print(order.ID);
      },
      child: Card(
        margin: EdgeInsets.fromLTRB(10, 5, 10, 5),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(20.0))),
        elevation: 4,
        child: Container(
          height: 150,
          child: Column(
            children: [
              Expanded(
                flex: 1,
                child: Container(
                  alignment: Alignment.center,

                  // color: Colors.cyan,
                  child: Row(
                    children: [
                      Expanded(
                        flex:4,
                        child: Container(
                          alignment:Alignment.centerRight,
                          child: Text( "تاریخ : "+order.Date,
                              style: TextStyle(
                                  color: BaseColor,
                                  fontFamily: "yekan",
                                  fontSize: 14)),
                        ),
                      ),
                      Expanded(
                        flex:1,
                        child: Container(
                            alignment:Alignment.centerLeft,
                            child: Icon(Icons.date_range_sharp,color: SecColor, textDirection: TextDirection.rtl)),
                      ),
                      Expanded(
                        flex:4,
                        child: Container(
                          alignment: Alignment.centerRight,
                          child: Text("شماره سفارش: " + order.ID.toString(),
                              style: TextStyle(
                                  color: BaseColor,
                                  fontFamily: "yekan",
                                  fontSize: 14)),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                            alignment:Alignment.centerLeft,
                            child: Icon(Icons.border_color,color: SecColor,size: 21,)),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  alignment: Alignment.center,

                  // color: Colors.cyan,
                  child: Row(
                    children: [
                      Expanded(
                        flex:4,
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 12, 0),
                          alignment:Alignment.centerRight,
                          child: Text( order.PayType,
                              style: TextStyle(
                                  color: BaseColor,
                                  fontFamily: "yekan",
                                  fontSize: 14)),
                        ),
                      ),
                      Expanded(
                        flex:1,
                        child: Container(
                            alignment:Alignment.centerLeft,
                            child: Icon(Icons.payments_outlined,color: SecColor, textDirection: TextDirection.rtl)),
                      ),
                      Expanded(
                        flex:4,
                        child: Container(
                          alignment: Alignment.centerRight,
                          child: Text("مبلغ: " + order.TotalPrice.toString()+" تومان",
                              style: TextStyle(
                                  color: BaseColor,
                                  fontFamily: "yekan",
                                  fontSize: 14)),
                        ),
                      ),
                      Expanded(
                        flex: 1,
                        child: Container(
                            alignment:Alignment.centerLeft,
                            child: Icon(Icons.price_change_outlined,color: SecColor,size: 21,)),
                      ),
                    ],
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: Container(
                  alignment: Alignment.center,

                  // color: Colors.cyan,
                  child: Row(
                    children: [
                      Expanded(
                        flex:5,
                        child: Container(
                          decoration: new BoxDecoration(
                            color: order.Active==0?ThirdColor:order.Active==1?Colors.cyan:order.Active==2?Colors.green:RedColor,
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                          margin:EdgeInsets.fromLTRB(20, 0, 20, 10),

                          alignment: Alignment.center,
                          child: Text(order.Active==0?"ثبت سفارش":order.Active==1?"در حال ارسال سفارش":order.Active==2?"ارسال شده":"لغو شده",style:TextStyle(color:Colors.white,fontFamily:"yekan")),
                        ),
                      ),
                      Expanded(
                        flex:5,
                        child: Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 25, 0),
                          child:Text("وضعیت سفارش: ",style:TextStyle(fontFamily:"yekan"),textDirection: TextDirection.rtl,)
                            )
                      ),

                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
