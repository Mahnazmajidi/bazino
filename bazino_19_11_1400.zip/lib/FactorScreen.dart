import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bazino/utils/constants.dart';
import 'package:bazino/View/BottomNav.dart';
import 'package:localstorage/localstorage.dart';
import 'package:url_launcher/url_launcher.dart';
import 'Controller/FactorController.dart';
import 'Model/FactorModel.dart';
import 'View/ApppBar.dart';
import 'View/Loading.dart';
import 'View/MyDrawer.dart';

class FactorScreen extends StatelessWidget {
  var _address = "";
  var _reciver = "";
  var _postalcode = "";
  var _formKey = GlobalKey<FormState>();
  String ReciverName="";
  RxInt payType = 1.obs;
  final LocalStorage storage = new LocalStorage('app');
  @override
  Widget build(BuildContext context) {
    // basketGlob[5] = 2;
    // basketGlob[6] = 3;
    ReciverName = storage.getItem('FName')+" "+storage.getItem('LName') ?? "";
    FactorController factorController = Get.put(FactorController());
    factorController.getFactor();
    return WillPopScope(
      onWillPop: () async {
        Get.offAndToNamed("/BasketScreen");
        return true;
      },
      child: Scaffold(
        endDrawer:MyDrawer(),
        // backgroundColor: Colors.white,
        body: Obx(() {
          return Container(
            decoration: new BoxDecoration(
              color: BaseColor,
              // borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
            ),
            child: Column(
              children: [
                ApppBar(title: "ثبت نهایی سفارش", back: "/BasketScreen"),
                Expanded(
                  flex: 1,
                  child: factorController.geted.value == 0
                      ? Loading()
                      : factorController.geted.value == 2
                          ? Container(child: Text(factorController.msg.value))
                          : Stack(
                              // overflow: Overflow.clip,
                              fit: StackFit.expand,
                              children: [
                                  Container(
                                    height: 200,
                                    margin: EdgeInsets.fromLTRB(10, 30, 10, 10),
                                    child: Card(
                                      semanticContainer: true,
                                      clipBehavior: Clip.antiAliasWithSaveLayer,
                                      // margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                                      color: GrayColor2,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(40.0))),
                                      elevation: 6,
                                      child: Container(
                                        height: 100,
                                      ),
                                    ),
                                  ),
                                  Container(
                                    margin: EdgeInsets.fromLTRB(15, 0, 15, 25),
                                    // transform: Matrix4.translationValues(0.0, -50.0, 0.0),
                                    child: Card(
                                      margin: EdgeInsets.fromLTRB(10, 5, 10, 5),
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(20.0))),
                                      elevation: 4,
                                      child: ListView.builder(
                                        itemCount:
                                            factorController.factor.length,
                                        itemBuilder: (context, position) {
                                          return genItem(factorController.factor[position], position, factorController.factor.length,factorController);
                                        },
                                        padding:
                                            EdgeInsets.fromLTRB(0, 0, 0, 0),
                                      ),
                                    ),
                                  )
                                ]),
                )
              ],
            ),
          );
        }),
        bottomNavigationBar: BottomNav(),
        floatingActionButton: FloatingActionButton(
          onPressed: (){
            Get.offAndToNamed("/CategoryScreen");
          },
          child: Icon(
            Icons.home,
            color: SecColor,
          ),
          backgroundColor: BaseColor,
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }

  Container genItem(FactorModel factor, int position, int lenth,factorController) {
    double TopRadius = 0.0;
    double ButtomRadius = 0;
    var rowColor = Colors.white;
    var textColor = Colors.black;
    if ((position + 1) % 2 == 0) {
      rowColor = Colors.black12;
    } else {
      rowColor = Colors.black26;
    }

    if (position == 0) {
      textColor = Colors.white;
      TopRadius = 20.0;
      rowColor = RedColor;
    }
    if (position + 1 == lenth) {
      textColor = Colors.white;
      ButtomRadius = 20.0;
      TopRadius = 0.0;
      rowColor = RedColor;
    }

    return position + 1 == lenth
        ? Container(
            child: Form(
                key: _formKey,
                child: Obx(() {
                  return Column(children: [
                    Container(
                      decoration: BoxDecoration(
                          color: rowColor,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(TopRadius),
                              topRight: Radius.circular(TopRadius),
                              bottomLeft: Radius.circular(ButtomRadius),
                              bottomRight: Radius.circular(ButtomRadius))),
                      child: Row(
                        children: [
                          Expanded(
                              child: Container(
                                alignment: Alignment.center,
                                height: 50,
                                margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                                child: Text(factor.Sum,
                                    style: TextStyle(
                                        color: textColor,
                                        fontFamily: "yekan",
                                        fontSize: 14)),
                                // alignment: Alignment.center,
                              ),
                              flex: 4),
                          Expanded(
                              child: Container(
                                alignment: Alignment.center,
                                height: 50,
                                margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                                child: Text(factor.Price,
                                    style: TextStyle(
                                        color: textColor,
                                        fontFamily: "yekan",
                                        fontSize: 14)),
                                // alignment: Alignment.center,
                              ),
                              flex: 4),
                          Expanded(
                              child: Container(
                                alignment: Alignment.center,
                                height: 50,
                                margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                                child: Text(factor.Amount,
                                    style: TextStyle(
                                        color: textColor,
                                        fontFamily: "yekan",
                                        fontSize: 14)),
                                // alignment: Alignment.center,
                              ),
                              flex: 3),
                          Expanded(
                              child: Container(
                                alignment: Alignment.center,
                                height: 50,
                                margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                                child: Text(factor.Name,textDirection: TextDirection.rtl,
                                    style: TextStyle(
                                        color: textColor,
                                        fontFamily: "yekan",
                                        fontSize: 14)),
                                // alignment: Alignment.center,
                              ),
                              flex: 4),
                        ],
                      ),
                    ),
                    1==1?Container():Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.fromLTRB(0, 40, 20, 0),
                      child: Text(
                        "نوع پرداخت:",
                        style: TextStyle(
                          fontFamily: "yekan",
                        ),
                        textDirection: TextDirection.rtl,
                      ),
                    ),
                    1==1?Container():Row(children: [
                      Expanded(
                          child: Container(
                        margin: EdgeInsets.fromLTRB(15, 5, 10, 0),
                        child: InkWell(
                          onTap: () {
                            payType.value = 2;
                          },
                          child: Card(
                            semanticContainer: true,
                            clipBehavior: Clip.antiAliasWithSaveLayer,
                            // margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                            color: GrayColor2,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20.0))),
                            elevation: 6,
                            child: Column(
                              children: [
                                Container(
                                    padding: EdgeInsets.fromLTRB(0, 15, 0, 0),
                                    child: Icon(Icons.credit_card)),
                                Container(
                                    padding: EdgeInsets.fromLTRB(0, 5, 0, 10),
                                    child: Text(
                                      "پرداخت آنلاین",
                                      style: TextStyle(fontFamily: "yekan"),
                                    )),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 15, 5),
                                  alignment: Alignment.bottomRight,
                                  width: 1000,
                                  height: 15.0,
                                  child: payType.value == 2
                                      ? Container(
                                          alignment: Alignment.bottomRight,
                                          width: 15.0,
                                          height: 15.0,
                                          decoration: new BoxDecoration(
                                            color: Colors.orange,
                                            shape: BoxShape.circle,
                                          ))
                                      : Container(
                                          alignment: Alignment.bottomRight,
                                          width: 15.0,
                                          height: 15.0,
                                        ),
                                )
                              ],
                            ),
                          ),
                        ),
                      )),
                      Expanded(
                          child: Container(
                        margin: EdgeInsets.fromLTRB(10, 5, 15, 0),
                        child: InkWell(
                          onTap: () {
                            payType.value = 1;
                          },
                          child: Card(
                            semanticContainer: true,
                            clipBehavior: Clip.antiAliasWithSaveLayer,
                            // margin: EdgeInsets.fromLTRB(0, 0, 0, 20),
                            color: GrayColor2,
                            shape: RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20.0))),
                            elevation: 6,
                            child: Column(
                              children: [
                                Container(
                                    padding: EdgeInsets.fromLTRB(0, 15, 0, 0),
                                    child: Icon(Icons.account_balance_wallet)),
                                Container(
                                    padding: EdgeInsets.fromLTRB(0, 5, 0, 10),
                                    child: Text(
                                      "پرداخت در محل",
                                      style: TextStyle(fontFamily: "yekan"),
                                    )),
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 15, 5),
                                  alignment: Alignment.bottomRight,
                                  width: 1000,
                                  height: 15.0,
                                  child: payType.value == 1
                                      ? Container(
                                          alignment: Alignment.bottomRight,
                                          width: 15.0,
                                          height: 15.0,
                                          decoration: new BoxDecoration(
                                            color: Colors.orange,
                                            shape: BoxShape.circle,
                                          ))
                                      : Container(
                                          alignment: Alignment.bottomRight,
                                          width: 15.0,
                                          height: 15.0,
                                        ),
                                )
                              ],
                            ),
                          ),
                        ),
                      )),
                    ]),
                    Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.fromLTRB(0, 40, 20, 10),
                      child: Text(
                        "آدرس تحویل سفارش:",
                        style: TextStyle(
                          fontFamily: "yekan",
                        ),
                        textDirection: TextDirection.rtl,
                      ),
                    ),
                    Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                      child: Directionality(
                        textDirection: TextDirection.rtl,
                        child: TextFormField(
                          keyboardType: TextInputType.multiline,
                          // maxLines: null,
                          minLines: 2,
                          //Normal textInputField will be displayed
                          maxLines: 5,
                          onSaved: (value) {
                            _address = value!;
                          },
                          validator: (value) {
                            if (value == "") {
                              return 'آدرس تحویل سفارش را وارد کنید';
                            } else if (value!.length < 3) {
                              return 'آدرس را به صورت دقیق وارد کنید';
                            } else {
                              return null;
                            }
                          },
                          style: TextStyle(fontSize: 14, color: BaseColor,fontFamily: 'yekan'),
                          textAlign: TextAlign.right,
                          decoration: InputDecoration(
                            // labelText: "آدرس:",
                            labelStyle: TextStyle(fontFamily: 'yekan'),
                            alignLabelWithHint: true,
                            hintTextDirection: TextDirection.rtl,
                            filled: true,
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: BaseColor)),
                            prefixIcon: Icon(Icons.location_history_rounded),
                          ),
                        ),
                      ),
                    ),




                    Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.fromLTRB(0, 20, 20, 10),
                      child: Text(
                        "نام و نام خانوادگی تحویل گیرنده:",
                        style: TextStyle(
                          fontFamily: "yekan",
                        ),
                        textDirection: TextDirection.rtl,
                      ),
                    ),
                    Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                      child: Directionality(
                        textDirection: TextDirection.rtl,
                        child: TextFormField(
                          controller: TextEditingController(text: ReciverName),
                          onSaved: (value) {
                            _reciver = value!;
                          },
                          validator: (value) {
                            if (value == "") {
                              return 'نام و نام خانوادگی تحویل گیرنده را وارد کنید';
                            } else if (value!.length < 3) {
                              return 'نام و نام خانوادگی تحویل گیرنده را به صورت دقیق وارد کنید';
                            } else {
                              return null;
                            }
                          },
                          style: TextStyle(fontSize: 14, color: BaseColor,fontFamily: 'yekan'),
                          textAlign: TextAlign.right,
                          decoration: InputDecoration(
                            // labelText: "آدرس:",
                            labelStyle: TextStyle(fontFamily: 'yekan'),
                            alignLabelWithHint: true,
                            hintTextDirection: TextDirection.rtl,
                            filled: true,
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: BaseColor)),
                            prefixIcon: Icon(Icons.contact_mail_outlined),
                          ),
                        ),
                      ),
                    ),
                    Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.fromLTRB(0, 20, 20, 10),
                      child: Text(
                        "کد پستی:",

                        style: TextStyle(
                          fontFamily: "yekan",
                        ),
                        textDirection: TextDirection.rtl,
                      ),
                    ),
                    Container(
                      alignment: Alignment.centerRight,
                      margin: EdgeInsets.fromLTRB(20, 0, 20, 10),
                      child: Directionality(
                        textDirection: TextDirection.rtl,
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          onSaved: (value) {
                            _postalcode = value!;
                          },
                          validator: (value) {
                            if (value == "") {
                              return 'کد پستی را وارد کنید';
                            } else if (value!.length != 10) {
                              return 'کد پستی را به صورت دقیق وارد کنید';
                            } else {
                              return null;
                            }
                          },
                          style: TextStyle(fontSize: 14, color: BaseColor),
                          textAlign: TextAlign.right,
                          decoration: InputDecoration(
                            // labelText: "آدرس:",
                            labelStyle: TextStyle(fontFamily: 'yekan'),
                            alignLabelWithHint: true,
                            hintTextDirection: TextDirection.rtl,
                            filled: true,
                            border: OutlineInputBorder(),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide(color: BaseColor)),
                            prefixIcon: Icon(Icons.local_post_office),
                          ),
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        _formKey.currentState!.validate();
                        _formKey.currentState!.save();
                        if (_formKey.currentState!.validate()) {
                          if(factorController.getedLink.value!=1){
                            Future<int> res = factorController.getPayLink(payType.value.toString(), _address);
                            res.then(
                                  (int value) {
                                if (value > 0) {
                                  _launchURL(factorController.link.value);
                                } else {
                                  Get.snackbar("..", "..",
                                      titleText: Text("خطا", textAlign: TextAlign.right, style: TextStyle(color: Colors.white, fontFamily: 'yekan'),),
                                      messageText: Text(factorController.msg.value, textAlign: TextAlign.right, style: TextStyle(color: Colors.white, fontFamily: 'yekan', fontSize: 16),),
                                      backgroundColor: Colors.black,
                                      icon: Icon(Icons.error, color: Colors.red, textDirection: TextDirection.rtl,),
                                      duration: Duration(seconds: 3),
                                      //     snackPosition: SnackPosition.BOTTOM,
                                      overlayColor: Colors.grey.withOpacity(0.5),
                                      dismissDirection:DismissDirection.horizontal,
                                      overlayBlur: 1,
                                      colorText: Colors.white);
                                }
                              },
                            );
                          }

                        }

                      },
                      child: Container(
                        // color:BaseColor,
                        margin: EdgeInsets.fromLTRB(10, 40, 10, 45),
                        height: 50,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            color: ThirdColor,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10))),
                        child: factorController.getedNew == 1 ? CircularProgressIndicator(color: BaseColor,)
                            : factorController.getedLink == 1 ?CircularProgressIndicator(color: BaseColor,)
                            : Text("ثبت سفارش", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'yekan'),),
                      ),
                    ),
                  ]);
                })))
        : Container(
            // splashColor: Colors.white,
            child: Container(
              decoration: BoxDecoration(
                  color: rowColor,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(TopRadius),
                      topRight: Radius.circular(TopRadius),
                      bottomLeft: Radius.circular(ButtomRadius),
                      bottomRight: Radius.circular(ButtomRadius))),
              child: Row(
                children: [
                  Expanded(
                      child: Container(
                        alignment: Alignment.center,
                        height: 50,
                        margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                        child: Text(factor.Sum,
                            style: TextStyle(
                                color: textColor,
                                fontFamily: "yekan",
                                fontSize: 14)),
                        // alignment: Alignment.center,
                      ),
                      flex: 4),
                  Expanded(
                      child: Container(
                        alignment: Alignment.center,
                        height: 50,
                        margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                        child: Text(factor.Price,
                            style: TextStyle(
                                color: textColor,
                                fontFamily: "yekan",
                                fontSize: 14)),
                        // alignment: Alignment.center,
                      ),
                      flex: 4),
                  Expanded(
                      child: Container(
                        alignment: Alignment.center,
                        height: 50,
                        margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                        child: Text(factor.Amount,
                            style: TextStyle(
                                color: textColor,
                                fontFamily: "yekan",
                                fontSize: 14)),
                        // alignment: Alignment.center,
                      ),
                      flex: 3),
                  Expanded(
                      child: Container(
                        alignment: Alignment.center,
                        height: 50,
                        margin: EdgeInsets.fromLTRB(0, 5, 0, 5),
                        child: Text(factor.Name,
                            style: TextStyle(
                                color: textColor,
                                fontFamily: "yekan",
                                fontSize: 14)),
                        // alignment: Alignment.center,
                      ),
                      flex: 4),
                ],
              ),
            ),
          );
  }
  _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
}
