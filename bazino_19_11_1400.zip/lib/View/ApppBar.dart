import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bazino/utils/constants.dart';
class ApppBar extends StatelessWidget {
  String title = AppName;
  String back = "";
  int IsHome=0;
  double marginTop=0;
  ApppBar({this.title = AppName,this.back = "",this.IsHome=0});

  @override
  Widget build(BuildContext context) {
    if(IsHome==1){
      this.marginTop=15;
    }

    return Container(
        padding: EdgeInsets.fromLTRB(0, 0, 0, 0),
        height: 90,
        alignment: Alignment.center,
        width: double.infinity,
        decoration: new BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(1)),
        ),
        child: Row(
          children: [
            Expanded(
              flex: 2,
              child: InkWell(
                onTap: (){
                  print(back);
                  if(back=="finish"){
                    Future.delayed(const Duration(milliseconds: 2000), () {
                      print("THIS");
                      // exit(0);
                      // SystemChannels.platform.invokeMethod('SystemNavigator.pop');
                    });
                    exit(0);
                  }
                 else if(back==""){
                    Get.back();

                  }
                  else{
                    Get.offAndToNamed(back);
                  }
                },
                  child: IsHome==0?Icon(
                Icons.arrow_back_ios,
                color: Colors.black87,
                size: 18,
              ):Container()),
            ),
            Expanded(
              flex: 6,
              child: IsHome==0?Text(title,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color:Colors.black87,
                      fontSize: 22,
                      fontFamily: 'yekan',
                      fontWeight: FontWeight.w700)):
              Container(
                padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
                child: Text("بازینو",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color:Colors.black,
                        fontSize: 22,
                        fontFamily: 'yekan',
                        fontWeight: FontWeight.w700)),
              )
              ,
            ),
            Expanded(
              flex: 2,
              child: Container(
                margin: EdgeInsets.fromLTRB(0, this.marginTop, 30, 0),
                  alignment: Alignment.centerRight,
                  child:InkWell(
                      onTap: (){
                        Scaffold.of(context).openEndDrawer();
                      },
                      child: Icon(Icons.menu,color: Colors.black87,size: 26,))),
            ),
          ],
        ));
  }
}
