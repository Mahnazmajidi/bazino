import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bazino/utils/constants.dart';
import 'package:localstorage/localstorage.dart';
final LocalStorage storage = new LocalStorage('app');
class BottomNav extends StatelessWidget {

  int isbasket=0;
  @override
  Widget build(BuildContext context) {
    int UserRef = storage.getItem('UserRef') ?? 0;

    return BottomAppBar(
      color: Colors.white ,
      child: Container(
        height: 60,
        color: Colors.white,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: InkWell(
                splashColor: Colors.black12,
                onTap: () {
                  if(UserRef==0){
                    Get.offAndToNamed("/ProfileScreen",arguments: ["جهت مشاهده ی سفارشات ابتدا وارد حساب کاربری خود شوید"]);
                  }
                  else{
                    Get.offAndToNamed("/OrdersScreen");
                  }
                },
                child: Container(
                    alignment: Alignment.center,
                    child: Icon(
                      Icons.fact_check_outlined,
                      color: Colors.black87,
                    )),
              ),
              flex: 2,
            ),
            Expanded(
              child: InkWell(
                splashColor: Colors.white,
                onTap: () {
                  if( basketGlob.length==0){
                    Get.snackbar("..", "..",
                        titleText: Text("خطا",textAlign: TextAlign.right,style: TextStyle(color:Colors.white,fontFamily: 'yekan'),),
                        messageText: Text("سبد خرید خالی است",textAlign: TextAlign.right,style: TextStyle(color:Colors.white,fontFamily: 'yekan',fontSize: 16),),
                        backgroundColor:Colors.black,
                        icon: Icon(Icons.error,color: Colors.red,textDirection: TextDirection.rtl,),
                        duration: Duration(seconds: 3),
                        // snackPosition: SnackPosition.BOTTOM,
                        overlayColor: Colors.grey.withOpacity(0.5 ),
                        dismissDirection: DismissDirection.horizontal,
                        overlayBlur: 1,
                        colorText: Colors.white);
                  }
                  else{
                    if(this.isbasket==0){
                      Get.offAndToNamed("/BasketScreen");
                    }
                  }
                },
                child: Container(
                      alignment: Alignment.center,
                      child: Icon(
                        Icons.local_grocery_store_outlined,
                        color: Colors.black87,
                      )) ,
              ),
              flex: 2,
            ),
            Expanded(
              child: Container(),
              flex: 2,
            ),
            Expanded(
              child: InkWell(
                splashColor: Colors.white,
                onTap: () {
                  Get.offAndToNamed("/SearchScreen");
                },
                child: Container(
                  alignment: Alignment.center,
                  child: Icon(Icons.search, color: Colors.black87),
                ),
              ),
              flex: 2,
            ),


            Expanded(
              child: InkWell(
                splashColor: Colors.black12,
                onTap: () {
                  Get.offAndToNamed("/ProfileScreen");
                },
                child: Container(
                    alignment: Alignment.center,
                    child: Icon(
                      Icons.account_circle,
                      color: Colors.black87,
                    )),
              ),
              flex: 2,
            ),

          ],
        ),
      ),
      shape: CircularNotchedRectangle(),
      notchMargin: 8,
      clipBehavior: Clip.antiAlias,
    );
  }

  BottomNav({int IsBasket=0}) {
    this.isbasket=IsBasket;
  }
}
