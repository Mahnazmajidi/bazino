import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bazino/utils/constants.dart';
class MyDrawer extends StatelessWidget {

  @override
  Widget build (BuildContext ctxt) {
    return ClipRRect(
      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(200.0),topLeft: Radius.circular(10.0)),
      child: new Drawer(
        backgroundColor: BaseColor,
          child: new ListView(
            children: <Widget>[
              new DrawerHeader(
                child: new Center(
                    child:Image(
                      image: AssetImage(
                          'assets/images/logo.png'),
                      height: 100,
                    )
                ),
                decoration: new BoxDecoration(
                    color: BaseColor
                ),
              ),
              ListTile(
                title: Divider(color: SecColor,),
                onTap: () {},
              ),
              ListTile(
                title:  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 10, 0),
                          child: Text("سفارشات",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                      Icon(Icons.fact_check_outlined,color: SecColor,)
                    ],
                  ),
                onTap: () {
                  Get.offAllNamed("/OrdersScreen");
                },
              ),
              ListTile(
                title:  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                          child: Text("جستجوی محصول",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                      Icon(Icons.search,color: SecColor,)
                    ],
                  ),
                onTap: () {
                  Get.offAllNamed("/SearchScreen");
                },
              ),
             ListTile(
                title:  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                          child: Text("حساب کاربری",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                      Icon(Icons.account_box,color: SecColor,)
                    ],
                  ),
                onTap: () {
                  Get.offAllNamed("/ProfileScreen");
                },
              ),
             ListTile(
                title:  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                          child: Text("مطالب و اخبار",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                      Icon(Icons.article_outlined,color: SecColor,)
                    ],
                  ),
                onTap: () {

                    Get.offAllNamed("/BlogScreen");
                },
              ),
              new ListTile(
                title:  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                          child: Text("آموزش ها",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                      Icon(Icons.live_help_rounded,color: SecColor,)
                    ],
                  ),
                onTap: () {

                  Get.offAllNamed("/LearnScreen");
                },
              ),
              ListTile(
                title:  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 5, 0),
                          child: Text("درباره ما",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                      Icon(Icons.chat,color: SecColor,)
                    ],
                  ),
                onTap: () {
                  Get.offAllNamed("/AboutScreen");
                },
              ),
              ListTile(
                title:  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 15, 0),
                          child: Text("قوانین",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                      Icon(Icons.warning_outlined,color: SecColor,)
                    ],
                  ),
                onTap: () {
                  Get.offAllNamed("/RulesScreen");
                },
              ),

              ListTile(
                title:  Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                        margin: EdgeInsets.fromLTRB(0, 0, 15, 0),
                        child: Text("خروج",style: TextStyle(color: SecColor,fontFamily: 'yekan',fontSize: 15),)),
                    Icon(Icons.exit_to_app,color: SecColor,)
                  ],
                ),
                onTap: () {
                    exit(0);
                },
              ),
            ],
          )
      ),
    );
  }
}