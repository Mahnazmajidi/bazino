import 'package:get/get.dart';
import 'package:bazino/Model/CategoryModel.dart';
import 'package:bazino/utils/constants.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class CategoryController extends GetxController {
  RxBool loading = true.obs;
  RxList <CategoryModel> product=<CategoryModel>[].obs;
  RxInt geted=0.obs;
  RxString msg="".obs;
  int catref=0;
  // onInit() {
  //   setProduct();
  // }
  Future<int> setCategory() async {
    geted.value=1;
    print(this.catref);
    var response = await http.post(Uri.parse(Api),
        body: {'action': 'getCategory', 'key': ApiKey}).timeout(const Duration(seconds: 4));

    // var response = await http.get(Uri.parse(Api+"/?action=getCategory")).timeout(const Duration(seconds: 4));
    print(response.toString());
    if (response.statusCode == 200) {
      var jsons = convert.jsonDecode(response.body);
      print(jsons["ok"].toString()+"_________________");
      if(jsons["ok"]==1){
        var data=jsons["data"];
        data.forEach((element) {

          var CatArr=[];
          if(element["CatArr"]!=null){
            CatArr=element["CatArr"];
            element["CatArr"].forEach((element2) {
              print(element2["Name"]);
            });

          }
          // else{
          //   CatArr=[];
          // }

          CategoryModel cModel=new CategoryModel(element["ID"],element["Name"],element["Pic"],element["BaseCat"],element["Cat"],CatArr);
          product.add(cModel);
        });
        geted.value=2;
        return 1;
      }
      else{
        geted.value=3;
        msg.value=jsons["msg"];
        return 0;
      }

      // print(category.length);

    } else {
      geted.value=3;
      msg.value="خطا در دریافت اطلاعات";
      print("ERR statusCode: "+response.statusCode.toString());
      return 0;
    }
    loading.value=false;

  }

  // ProductController(int cat) {
  //   this.catref=cat;
  //
  // }
}
