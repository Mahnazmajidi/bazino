import 'dart:async';
import 'dart:io';

import 'package:get/get.dart';
import 'package:localstorage/localstorage.dart';
import 'package:bazino/utils/constants.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;

class SigninController extends GetxController {
  // RxBool loading = true.obs;
  RxInt code=0.obs;
  RxInt geted=0.obs;
  RxInt getedsignup=0.obs;
  RxInt showmsg=0.obs;
  RxString msg="".obs;
  RxString signmsg="".obs;
  late Timer _timer;
  RxInt start = 120.obs;
  final LocalStorage storage = new LocalStorage('app');
  sendsms(String Mobile) async {
    geted.value=1;
    final result = await InternetAddress.lookup('example.com');
    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
      var response = await http.post(Uri.parse(Api),
          body: {'action': 'sendsms','Mobile': Mobile, 'key': ApiKey}).timeout(const Duration(seconds: 15));
      if (response.statusCode == 200) {
        var jsons = convert.jsonDecode(response.body);
        print(jsons);
        if(jsons["ok"]==1){

          code.value=jsons["code"];
          geted.value=2;
          start.value = 120;
          showmsg.value=1;
          return 1;
        }
        else {
          geted.value=3;
          print("ERR ok");
          return 0;
        }
      } else {
        geted.value=3;
        print("ERR statusCode");
        return 3;
      }
    }
    else{
      geted.value=4;
      msg.value="اینترنت شما وصل نیست";
    }

  }
  Future<int> signin(String mobile,String code) async {
    getedsignup.value=1;
    final result = await InternetAddress.lookup('example.com');
    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
      var response = await http.post(Uri.parse(Api),
          body: {'action': 'signin','mobile': mobile,'code': code,'AppVersion': AppVersion, 'key': ApiKey}).timeout(const Duration(seconds: 4));;
      if (response.statusCode == 200) {
        var jsons = convert.jsonDecode(response.body);
        print(jsons);
        if(jsons["ok"]==1){
          getedsignup.value=2;
          signmsg.value=jsons["msg"];

          // int counter = (prefs.getInt('counter') ?? 0) + 1;
          storage.setItem('UserRef', jsons["UserRef"]);
          storage.setItem('FName', jsons["FName"].toString());
          storage.setItem('LName', jsons["LName"].toString());
          storage.setItem('Mobile', jsons["Mobile"].toString());
          return 1;
        }
        else {
          getedsignup.value=3;
          signmsg.value=jsons["msg"];
          print("ERR ok");
          return 0;
        }
      } else {
        getedsignup.value=3;
        signmsg.value="خطا در دریافت اطلاعات";
        print("ERR statusCode");
        return 0;
      }
    }
    else{
      geted.value=4;
      signmsg.value="اینترنت شما وصل نیست";
      return 0;
    }

  }
  void startTimer() {
    start.value = 120;
    const oneSec = const Duration(seconds: 1);
    _timer = new Timer.periodic(
      oneSec,
          (Timer timer) {
        if (start.value == 0) {
          timer.cancel();
        } else {
          start.value=start.value-1;
        }
      },
    );
  }
}
