import 'package:get/get.dart';
import 'package:flutter/material.dart';

class animController extends GetxController with SingleGetTickerProviderMixin {
  late AnimationController controller;
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    controller = AnimationController(
      vsync: this,
      duration: const Duration(
        milliseconds: 1000,
      ),
    );
  }
}