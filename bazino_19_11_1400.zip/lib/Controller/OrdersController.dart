import 'dart:io';

import 'package:get/get.dart';
import 'package:bazino/Model/OrdersModel.dart';
import 'package:bazino/utils/constants.dart';
import 'dart:convert' as convert;
import 'package:http/http.dart' as http;
import 'package:localstorage/localstorage.dart';
final LocalStorage storage = new LocalStorage('app');
class OrdersController extends GetxController {
  int UserRef = storage.getItem('UserRef') ?? 0;
  RxBool loading = true.obs;
  RxList <OrdersModel> order=<OrdersModel>[].obs;
  RxInt geted=0.obs;
  RxString msg="".obs;
  onInit() {
    setOrder();
  }
  setOrder() async {
    geted.value=1;
    final result = await InternetAddress.lookup('example.com');
    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
      var response = await http.post(Uri.parse(Api),
          body: {'action': 'getOrders', 'key': ApiKey, 'UserRef': UserRef.toString()});
      if (response.statusCode == 200) {
        print(response.body);
        var jsons = convert.jsonDecode(response.body);
        var data=jsons["data"];
        var ok=jsons["ok"];
        if(ok==1){
          geted.value=2;
          data.forEach((element) {
            OrdersModel cModel=new OrdersModel(element["ID"],element["Active"],element["Price"],element["TotalPrice"],element["PayType"],element["Date"]);
            order.add(cModel);
          });
        }
        else{
          geted.value=3;
          msg.value=jsons["msg"];
        }
        // print(data);

        // print(category.length);

      } else {
        geted.value=3;
        msg.value="خطا در دریافت اطلاعات";
      }
    }
    else{
      geted.value=4;
      msg.value="اینترنت شما وصل نیست";
    }


  }
}
