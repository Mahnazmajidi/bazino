import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bazino/OrderDetailScreen.dart';
import 'package:bazino/SplashScreen.dart';
import 'package:bazino/utils/constants.dart';
import 'AboutScreen.dart';
import 'AddressScreen.dart';
import 'CategoryScreen.dart';
import 'EditAddressScreen.dart';
import 'FactorScreen.dart';
import 'HomeScreen.dart';
import 'NewAddressScreen.dart';
import 'OrdersScreen.dart';
import 'PaymentScreen.dart';
import 'ProfileScreen.dart';
import 'ResultpayScreen.dart';
import 'RulesScreen.dart';
import 'SignupScreen.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: "Bazino",
      initialRoute: "/AddressScreen",
      debugShowCheckedModeBanner: false,
      defaultTransition: Transition.fadeIn,
      color: BaseColor,
      getPages: [
        GetPage(name: "/SplashScreen", page: ()=>SplashScreen()),
        GetPage(name: "/HomeScreen", page: ()=>HomeScreen()),
        GetPage(name: "/FactorScreen", page: ()=>FactorScreen()),
        GetPage(name: "/PaymentScreen", page: ()=>PaymentScreen()),
        GetPage(name: "/ProfileScreen", page: ()=>ProfileScreen()),
        GetPage(name: "/SignupScreen", page: ()=>SignupScreen()),
        GetPage(name: "/OrdersScreen", page: ()=>OrdersScreen()),
        GetPage(name: "/OrderDetailScreen", page: ()=>OrderDetailScreen()),
        GetPage(name: "/ResultpayScreen", page: ()=>ResultpayScreen()),
        GetPage(name: "/AboutScreen", page: ()=>AboutScreen()),
        GetPage(name: "/RulesScreen", page: ()=>RulesScreen()),
        GetPage(name: "/CategoryScreen", page: ()=>CategoryScreen()),
        GetPage(name: "/AddressScreen", page: ()=>AddressScreen()),
        GetPage(name: "/NewAddressScreen", page: ()=>NewAddressScreen()),
        GetPage(name: "/EditAddressScreen", page: ()=>EditAddressScreen()),
      ],
    );
  }
}



