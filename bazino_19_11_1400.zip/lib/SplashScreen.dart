import 'package:flutter/material.dart';
import 'package:bazino/utils/constants.dart';
import 'package:get/get.dart';

import 'View/MyDrawer.dart';

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {

    Future.delayed(const Duration(milliseconds: 2000), () {
      // Navigator.pushReplacement(
      //     context, MaterialPageRoute(builder: (context) => HomeScreen()));

      Get.offAndToNamed("/CategoryScreen");
    });
    return Scaffold(
      endDrawer:MyDrawer(),
      backgroundColor: BaseColor,
      body: Center(
        child: Container(
          child: GestureDetector(
            child: Container(
                margin: EdgeInsets.fromLTRB(50, 0, 50, 0),
                child: Image(image: AssetImage('assets/images/logo.png'),)),
            onTap: () {
              Get.offAndToNamed("/CategoryScreen");
              // Navigator.push(context,
              //     MaterialPageRoute(builder: (context) => HomeScreen()));
            },
          ),
        ),
      ),
    );
  }
}
