package ir.sitecoder.bazino.bazino

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
